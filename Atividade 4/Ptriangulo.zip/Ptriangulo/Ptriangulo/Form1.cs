﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C, resultado;

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out A) ||
                A <= 0)
            {
                MessageBox.Show("Valor de *A* inválido!");
                txtA.Focus();
            }
                
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out B) ||
                B <= 0)
            {
                MessageBox.Show("Valor de *B* inválido!");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtC.Text, out C) ||
                C <= 0)
            {
                MessageBox.Show("Valor de *C* inválido!");
                txtC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (A + B > C && Math.Abs(A - B) < C && B + C > A && Math.Abs(B - C) < A && C + A > B && Math.Abs(C - A) < B)
            {

                if (A == B && B == C)
                    MessageBox.Show("Triângulo Equilátero.");
                else
                    if (A != B && B != C)
                    MessageBox.Show("Triângulo Escaleno.");
                else
                    MessageBox.Show("Triângulo Isósceles.");
            }
            else
                MessageBox.Show("Isso não é um triangulo!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
