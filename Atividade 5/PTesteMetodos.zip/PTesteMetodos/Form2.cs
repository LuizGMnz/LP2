﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
            int resultado = string.Compare(txtPalavra1.Text, txtPalavra2.Text);

            if (resultado == 0)
                MessageBox.Show("As palavras são iguais.");
            else
                MessageBox.Show("As palavras são diferentes.");
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            int meio = palavra2.Length / 2;
            string resultado = palavra2.Substring(0, meio) + palavra1 + palavra2.Substring(meio);

            txtPalavra2.Text = resultado;
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            int meio = palavra1.Length / 2;
            string resultado = palavra1.Insert(meio, "**");

            txtPalavra2.Text = resultado;
        }
    }
}
