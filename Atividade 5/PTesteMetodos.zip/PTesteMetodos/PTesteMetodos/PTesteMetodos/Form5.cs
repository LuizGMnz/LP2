﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Form5 : Form
    {
        int Numero1, Numero2;

        public Form5()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out Numero2) && txtNumero2.Text != "")
            {
                MessageBox.Show("Informe somente números!");
                txtNumero2.Clear();
                txtNumero2.Focus();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out Numero1) && txtNumero1.Text != "")
            {
                MessageBox.Show("Informe somente números!");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random ObjR = new Random();
            for (int i = 0; i < 2; i++)
            {
                int r = ObjR.Next(0, 1000);
                if (i == 0)
                {
                    txtNumero1.Text = r.ToString();
                    Numero1 = r;
                }
                else
                {
                    txtNumero2.Text = r.ToString();
                    Numero2 = r;
                }
            }
            if (Numero1 < Numero2)
                MessageBox.Show("1º Número é menor que 2º Número.");
            else
                MessageBox.Show("1º Número não é menor que 2º Número.");
        }

        private void btnSortear_Validated(object sender, EventArgs e)
        {
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
