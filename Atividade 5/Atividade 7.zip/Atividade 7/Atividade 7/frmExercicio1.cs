﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Atividade_7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;
            for (int i = 0; i < rchtxtTexto.Text.Length; i++)
                if (char.IsWhiteSpace(rchtxtTexto.Text[i]))
                { 
                    cont = cont + 1;
                }

            MessageBox.Show($"A quantidade de espaços em branco é: {cont}");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchtxtTexto.Clear();
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char Caracter in rchtxtTexto.Text.ToUpper())
                if (Caracter == 'R')
                {
                    cont = cont + 1;
                }
            MessageBox.Show($"A quantidade de letras 'R' é: {cont}");

        }
    }
}
