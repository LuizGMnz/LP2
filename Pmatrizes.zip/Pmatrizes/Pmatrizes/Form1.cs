﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int a = 0; a < vetor.Length; a++)
            {
                aux = Interaction.InputBox($"Digite o {a + 1}º numero ", "Entrada de Dados");
                if (aux == "")
                {
                    break;
                }

                if (!int.TryParse(aux, out vetor[a]))
                {
                    MessageBox.Show("Número inválido.");
                    a--;
                }
            }
            Array.Reverse(vetor);
            aux = "";
            foreach (int b in vetor)
            {
                aux += b + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"};
            alunos.Remove("Otávio");

            string lista = string.Join("\n", alunos.Cast<string>().ToArray());
            MessageBox.Show(lista);
        }
    }
}
