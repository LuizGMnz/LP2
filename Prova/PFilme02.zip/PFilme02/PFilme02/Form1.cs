﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] tabOpinioes = new double[2, 2];
            double[] aux = new double[2];
            double media;

            for (int i = 0; i < 2; i++)
            {
                aux[i] = 0;
                for (int j = 0; j < 2; j++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Nota do filme {i + 1}, Pessoa {j + 1}:"), out tabOpinioes[i, j]) || (tabOpinioes[i, j] > 10) || (tabOpinioes[i, j] < 0))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                        aux[i] += tabOpinioes[i, j];
                }
            }
            for (int i = 0; i < 2; i++)
            {
                media = aux[i];
                for (int j = 0; j < 2; j++)
                {
                    listBox1.Items.Add($"Nota do Filme {i + 1} Pessoa {j + 1} : {tabOpinioes[i, j].ToString("N2")}");


                }
                media = media / 2;
                listBox1.Items.Add($"-> Média do Filme: {media.ToString("N2")}");
                listBox1.Items.Add("---------------------------------------------");
            }
        }

    }
}

